/* Syncwire Returns Dashboard V6.0 */
const $ = (id) => document.getElementById(id);
const fmt = (n) => Number(n || 0).toLocaleString('zh-CN');
const pct = (n) => (Number(n || 0) * 100).toFixed(2) + '%';
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const colors = ['#2563eb','#16a34a','#f59e0b','#dc2626','#7c3aed','#0891b2','#db2777','#475569','#65a30d','#ea580c'];
const state = { sales: [], returns: [], rows: [], filtered: [], skuAgg: [], page: 1, pageSize: 100, selected: new Set(), salesFile: null, returnsFile: null, meta: {} };
const qeStateKey = 'syncwire_dashboard_qe_v6';
let qeState = JSON.parse(localStorage.getItem(qeStateKey) || '{}');
function saveQE(){ localStorage.setItem(qeStateKey, JSON.stringify(qeState)); }
function setStatus(msg, type=''){ const el=$('uploadStatus'); el.className='status '+type; el.textContent=msg; }
function val(obj, names){ for(const n of names){ if(obj[n] !== undefined && obj[n] !== null && obj[n] !== '') return obj[n]; } return ''; }
function normHeader(h){ return String(h ?? '').replace(/\s+/g,'').trim(); }
function countryFromStore(store){ const s=String(store||'').toUpperCase(); if(s.includes('-US'))return '美国'; if(s.includes('-JP'))return '日本'; if(s.includes('-DE'))return '德国'; if(s.includes('-UK')||s.includes('-GB'))return '英国'; if(s.includes('-CA'))return '加拿大'; if(s.includes('-FR'))return '法国'; if(s.includes('-IT'))return '意大利'; if(s.includes('-ES'))return '西班牙'; return ''; }
function skuFromName(name){ const s=String(name||''); const m=s.match(/\/([A-Za-z0-9._-]+)\s*$/); return m?m[1]:''; }
function toNum(x){ if(typeof x==='number')return x; const n=parseFloat(String(x||'').replace(/,/g,'')); return isNaN(n)?0:n; }
function toDateStr(x){ if(!x) return ''; if(x instanceof Date && !isNaN(x)) return x.toISOString().slice(0,10); const s=String(x).trim(); const m=s.match(/(20\d{2})[-\/\.](\d{1,2})[-\/\.](\d{1,2})/); if(m) return `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`; const d=new Date(s); return isNaN(d)?'':d.toISOString().slice(0,10); }
function weekOf(dateStr){ const d = new Date(dateStr+'T00:00:00'); if(isNaN(d)) return ''; const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); const dayNum = date.getUTCDay() || 7; date.setUTCDate(date.getUTCDate() + 4 - dayNum); const yearStart = new Date(Date.UTC(date.getUTCFullYear(),0,1)); const week = Math.ceil((((date - yearStart) / 86400000) + 1)/7); return date.getUTCFullYear() + '-W' + String(week).padStart(2,'0'); }
function groupOf(cat, brand){ const c=String(cat||''), b=String(brand||''); if(/钢化膜|防窥|透明钢化/.test(c)) return '钢化膜'; if(/保护|防水袋|AirTag|壳/.test(c)) return '保护类'; if(/支架|Magsafe|MagSafe|指环/.test(c)) return '支架类'; if(/车充|充电|FM/.test(c)) return '车充/充电类'; if(/音频|Aux|线材|3\.5/.test(c)) return '音视频线/线材'; if(/自拍杆|三脚架/.test(c) || /Atumtek/i.test(b)) return 'Atumtek配件/自拍杆'; return c || '其他'; }
function ownerOf(group, brand){ if(group==='支架类' && brand==='Syncwire') return '郑春霞'; if(['钢化膜','保护类','Atumtek配件/自拍杆'].includes(group) || /UNBREAKcable|Atumtek/i.test(brand)) return '崔永梅'; return '未指定/其他'; }
function reasonGroupOf(reason, remark){ const s=(String(reason||'')+' '+String(remark||'')).toUpperCase(); if(/DEFECTIVE|QUALITY|DAMAGED|MISSING|SWITCHEROO|破损|瑕疵|质量|缺失|BROKEN/.test(s)) return '产品质量/破损缺件'; if(/NOT_COMPATIBLE|NOT_AS_DESCRIBED|WRONG|TOO_SMALL|TOO_LARGE|尺寸|不兼容|描述/.test(s)) return '兼容/描述/尺寸问题'; if(/UNDELIVERABLE|DELIVERY|NEVER_ARRIVED|MISSED|LATE|物流|送达/.test(s)) return '物流配送问题'; if(/UNWANTED|CHANGED|FOUND_BETTER|ORDERED_WRONG|AUTHORIZED|PRICE|不想要|订购错误/.test(s)) return '客户主观/下错单'; if(/NO_REASON/.test(s)) return '未提供原因'; return '其他原因'; }
function riskOf(group, rate, sales){ if(!sales) return '无销量'; const r=Number(rate||0); let y=.05, red=.08; if(group==='支架类'){ y=.06; red=.10; } else if(group==='音视频线/线材'){ y=.04; red=.07; } else if(group==='Atumtek配件/自拍杆'){ y=.07; red=.10; } if(r <= y) return '健康'; if(r < red) return '关注'; return '高风险'; }
function slaOf(row){ const q=qeState[row.key] || {}; if(q.status==='已处理' || q.status==='不需处理') return q.status; const d=new Date((row.firstDate||row.date||'')+'T00:00:00'); if(isNaN(d)) return '正常'; const now=new Date(); const days=Math.floor((now-d)/86400000); if(days>15) return '已超期'; if(days>=10) return '即将超期'; return '正常'; }
function qestatus(key){ return (qeState[key] && qeState[key].status) || '待处理'; }
function noteFor(key){ return (qeState[key] && qeState[key].note) || ''; }

async function readWorkbook(file){
  if(!window.XLSX) throw new Error('XLSX解析库未加载。请确认网络可访问 cdn.jsdelivr.net，或改用本地 xlsx.full.min.js。');
  const buf = await file.arrayBuffer();
  return XLSX.read(buf, {type:'array', cellDates:true});
}
function sheetRows(wb){ const ws=wb.Sheets[wb.SheetNames[0]]; return XLSX.utils.sheet_to_json(ws, {header:1, defval:''}); }
async function fileToRows(file){
  if(/\.csv$/i.test(file.name)){ const text=await file.text(); return text.split(/\r?\n/).filter(Boolean).map(line => line.split(',')); }
  const wb=await readWorkbook(file); return sheetRows(wb);
}
async function extractFirstSheetFileFromZip(file){
  const zip = await JSZip.loadAsync(await file.arrayBuffer());
  const names = Object.keys(zip.files).filter(n => /\.(xlsx|xls|csv)$/i.test(n) && !zip.files[n].dir && !/__MACOSX/.test(n));
  if(!names.length) throw new Error('ZIP中没有找到Excel或CSV文件');
  const name = names[0];
  const blob = await zip.files[name].async('blob');
  return new File([blob], name, {type: blob.type || 'application/octet-stream'});
}
function parseSales(rows){
  if(!rows || rows.length<2) return [];
  let headerRow = rows.findIndex(r => r.some(c => normHeader(c)==='ASIN'));
  if(headerRow<0) headerRow=0;
  const h1=rows[headerRow].map(normHeader), h2=(rows[headerRow+1]||[]).map(normHeader);
  const idx = (names) => h1.findIndex(h => names.includes(h));
  const asinI=idx(['ASIN']); const nameI=idx(['品名/SKU','品名SKU','品名','SKU']); const storeI=idx(['店铺']); const countryI=idx(['国家']);
  let salesI = -1, period='';
  for(let i=0;i<Math.max(h1.length,h2.length);i++){
    if(h2[i]==='销量' || h1[i]==='销量'){ salesI=i; period=h1[i] || ''; break; }
  }
  if(salesI<0) throw new Error('销售表未识别到“销量”列');
  const out=[];
  for(let r=headerRow+2;r<rows.length;r++){
    const row=rows[r]; if(!row || row.every(x=>x==='')) continue;
    const name=row[nameI] || ''; const sku=skuFromName(name) || row[nameI] || '';
    const asin=row[asinI] || ''; const store=row[storeI] || ''; const country=row[countryI] || countryFromStore(store);
    const sales=toNum(row[salesI]); if(!asin && !sku && !sales) continue;
    const brand = String(name).split(/\s+/)[0] || '';
    out.push({asin:String(asin), sku:String(sku), name:String(name), store:String(store), country:String(country), sales, brand, period});
  }
  return out;
}
function parseReturns(rows){
  if(!rows || rows.length<2) return [];
  let headerRow = rows.findIndex(r => r.some(c => ['sku','SKU'].includes(String(c).trim())) && r.some(c => /退货|原因|ASIN/i.test(String(c))));
  if(headerRow<0) headerRow=0;
  const headers=rows[headerRow].map(h=>String(h||'').trim());
  const find=(patterns)=> headers.findIndex(h => patterns.some(p => p.test(h)));
  const storeI=find([/^店铺$/,/store/i]); const countryI=find([/^国家$/,/country/i]); const skuI=find([/^sku$/i,/^SKU$/]); const catI=find([/^分类$/,/品类|类别/]); const brandI=find([/^品牌$/,/brand/i]); const orderI=find([/订单号|order/i]); const asinI=find([/^ASIN$/i]); const qtyI=find([/退货数量|数量|qty/i]); const reasonI=find([/退货原因|原因|reason/i]); const remarkI=find([/买家备注|备注|comment|remark/i]); const dateI=find([/退货时间|退货日期|date/i]);
  const out=[];
  for(let r=headerRow+1;r<rows.length;r++){
    const row=rows[r]; if(!row || row.every(x=>x==='')) continue;
    const sku=String(row[skuI]||'').trim(); const asin=String(row[asinI]||'').trim(); if(!sku && !asin) continue;
    const store=String(row[storeI]||'').trim(); const country=String(row[countryI]||countryFromStore(store)).trim(); const category=String(row[catI]||'').trim(); const brand=String(row[brandI]||'').trim(); const group=groupOf(category,brand); const reason=String(row[reasonI]||'').trim(); const remark=String(row[remarkI]||'').trim(); const date=toDateStr(row[dateI]);
    out.push({id:out.length+1,store,country,sku,category,group,brand,asin,order:String(row[orderI]||''),returnQty:toNum(row[qtyI])||1,reason,reasonGroup:reasonGroupOf(reason,remark),remark,owner:ownerOf(group,brand),date,year:date?date.slice(0,4):'',month:date?date.slice(0,7):'',week:date?weekOf(date):'',day:date});
  }
  return out;
}
function recomputeRows(){
  const salesMap=new Map();
  for(const s of state.sales){ const key=(s.asin+'|'+s.country).toUpperCase(); salesMap.set(key, (salesMap.get(key)||0)+s.sales); }
  const retMap=new Map();
  for(const r of state.returns){ const key=(r.asin+'|'+r.country).toUpperCase(); retMap.set(key, (retMap.get(key)||0)+r.returnQty); }
  state.rows = state.returns.map((r,i)=>{ const key=(r.asin+'|'+r.country).toUpperCase(); const skuCountrySales=salesMap.get(key)||0; const skuCountryReturns=retMap.get(key)||0; const skuCountryRate=skuCountrySales?skuCountryReturns/skuCountrySales:0; const risk=riskOf(r.group,skuCountryRate,skuCountrySales); return {...r,id:i+1,skuCountrySales,skuCountryReturns,skuCountryRate,risk,key:`${r.sku}|${r.asin}|${r.country}`}; });
  state.meta.salesTotal = state.sales.reduce((a,b)=>a+b.sales,0); state.meta.returnTotal=state.rows.reduce((a,b)=>a+b.returnQty,0); state.meta.rowCount=state.rows.length;
}
function fillSelect(id, arr){ const el=$(id); const cur=el.value; el.innerHTML='<option value="">全部</option>'+[...new Set(arr.filter(Boolean))].sort().map(x=>`<option>${esc(x)}</option>`).join(''); if([...el.options].some(o=>o.value===cur)) el.value=cur; }
function refreshFilters(){ const r=state.rows; fillSelect('fYear', r.map(x=>x.year)); fillSelect('fMonth', r.map(x=>x.month)); fillSelect('fWeek', r.map(x=>x.week)); fillSelect('fDay', r.map(x=>x.day)); fillSelect('fCountry', r.map(x=>x.country)); fillSelect('fBrand', r.map(x=>x.brand)); fillSelect('fGroup', r.map(x=>x.group)); fillSelect('fCategory', r.map(x=>x.category)); fillSelect('fOwner', r.map(x=>x.owner)); fillSelect('fRisk', r.map(x=>x.risk)); fillSelect('fReasonGroup', r.map(x=>x.reasonGroup)); updateTrendValueOptions(); }
function getFilters(){ return {year:$('fYear').value,month:$('fMonth').value,week:$('fWeek').value,day:$('fDay').value,country:$('fCountry').value,brand:$('fBrand').value,group:$('fGroup').value,category:$('fCategory').value,owner:$('fOwner').value,risk:$('fRisk').value,reasonGroup:$('fReasonGroup').value,qe:$('fQE').value,sla:$('fSLA').value,search:$('fSearch').value.trim().toLowerCase()}; }
function applyFilters(){ const f=getFilters(); state.filtered=state.rows.filter(r=>{ if(f.year&&r.year!==f.year)return false; if(f.month&&r.month!==f.month)return false; if(f.week&&r.week!==f.week)return false; if(f.day&&r.day!==f.day)return false; if(f.country&&r.country!==f.country)return false; if(f.brand&&r.brand!==f.brand)return false; if(f.group&&r.group!==f.group)return false; if(f.category&&r.category!==f.category)return false; if(f.owner&&r.owner!==f.owner)return false; if(f.risk&&r.risk!==f.risk)return false; if(f.reasonGroup&&r.reasonGroup!==f.reasonGroup)return false; if(f.qe&&qestatus(r.key)!==f.qe)return false; if(f.sla&&slaOf(r)!==f.sla)return false; if(f.search){ const hay=[r.sku,r.asin,r.order,r.reason,r.remark,r.category,r.brand,r.country].join(' ').toLowerCase(); if(!hay.includes(f.search))return false; } return true; }); state.page=1; renderAll(); }
function aggBy(rows, key){ const m=new Map(); for(const r of rows){ const k=r[key]||'未指定'; if(!m.has(k))m.set(k,{name:k,returns:0,sales:0,sku:new Set(),high:0}); const o=m.get(k); o.returns+=r.returnQty; o.sales+=r.skuCountrySales; o.sku.add(r.sku); } return [...m.values()].map(o=>({...o,sku:o.sku.size,rate:o.sales?o.returns/o.sales:0})).sort((a,b)=>b.returns-a.returns); }
function aggregateSku(rows){ const m=new Map(); for(const r of rows){ const k=r.key; if(!m.has(k))m.set(k,{key:k,sku:r.sku,asin:r.asin,country:r.country,brand:r.brand,category:r.category,group:r.group,owner:r.owner,returns:0,sales:r.skuCountrySales,firstDate:r.date,reasonMap:new Map(),risk:r.risk,rate:r.skuCountryRate}); const o=m.get(k); o.returns+=r.returnQty; if(r.date && (!o.firstDate || r.date<o.firstDate))o.firstDate=r.date; o.reasonMap.set(r.reasonGroup,(o.reasonMap.get(r.reasonGroup)||0)+r.returnQty); }
  return [...m.values()].map(o=>{ const top=[...o.reasonMap.entries()].sort((a,b)=>b[1]-a[1])[0]; return {...o,topReason:top?top[0]:'',qe:qestatus(o.key),sla:slaOf(o),note:noteFor(o.key)}; }).sort((a,b)=>b.sales-a.sales || b.returns-a.returns); }
function renderKpis(){ const skuAgg=aggregateSku(state.filtered); state.skuAgg=skuAgg; const sales=[...new Set(skuAgg.map(x=>x.key))].reduce((a,k)=>{ const o=skuAgg.find(x=>x.key===k); return a+(o?o.sales:0); },0); const returns=state.filtered.reduce((a,b)=>a+b.returnQty,0); $('kpiSales').textContent=fmt(sales); $('kpiReturns').textContent=fmt(returns); $('kpiRate').textContent=sales?pct(returns/sales):'-'; $('kpiRows').textContent=fmt(state.filtered.length); $('kpiSku').textContent=fmt(skuAgg.length); $('kpiHigh').textContent=fmt(skuAgg.filter(x=>x.risk==='高风险').length); $('kpiOver').textContent=fmt(skuAgg.filter(x=>x.sla==='已超期').length); $('kpiDone').textContent=fmt(skuAgg.filter(x=>['已处理','不需处理'].includes(x.qe)).length); }
function renderBars(id, data){ const max=Math.max(1,...data.map(d=>d.returns)); $(id).innerHTML=data.slice(0,10).map(d=>`<div class="barrow"><div title="${esc(d.name)}">${esc(String(d.name).slice(0,12))}</div><div class="bar"><span style="width:${100*d.returns/max}%"></span></div><div class="num">${fmt(d.returns)}</div></div>`).join('') || '<div class="small">暂无数据</div>'; }
function renderPie(id, legendId, data){ const total=data.reduce((a,b)=>a+b.returns,0); if(!total){ $(id).style.background='#e5e7eb'; $(legendId).innerHTML='<span class="small">暂无数据</span>'; return; } let acc=0; const parts=data.slice(0,8).map((d,i)=>{ const p=d.returns/total*100; const s=acc; acc+=p; return `${colors[i%colors.length]} ${s}% ${acc}%`; }); $(id).style.background=`conic-gradient(${parts.join(',')})`; $(legendId).innerHTML=data.slice(0,8).map((d,i)=>`<div><span class="dot" style="background:${colors[i%colors.length]}"></span>${esc(d.name)}：${pct(d.returns/total)}</div>`).join(''); }
function table(id, headers, rows){ $(id).innerHTML='<thead><tr>'+headers.map(h=>`<th>${h}</th>`).join('')+'</tr></thead><tbody>'+rows.join('')+'</tbody>'; }
function renderSummary(){ const country=aggBy(state.filtered,'country'), brand=aggBy(state.filtered,'brand'), group=aggBy(state.filtered,'group'); renderBars('countryBars',country); renderPie('countryPie','countryLegend',country); renderBars('brandBars',brand); renderPie('brandPie','brandLegend',brand); renderBars('groupBars',group); renderPie('groupPie','groupLegend',group); const row=o=>`<tr><td>${esc(o.name)}</td><td class="num">${fmt(o.sales)}</td><td class="num">${fmt(o.returns)}</td><td class="num">${pct(o.rate)}</td><td class="num">${fmt(o.sku)}</td></tr>`; const headers=['维度','销量','退货量','退货率','SKU数']; table('tblCountry',headers,country.map(row)); table('tblBrand',headers,brand.map(row)); table('tblGroup',headers,group.map(row)); }
function renderSku(){ const rows=state.skuAgg.map(o=>`<tr><td>${esc(o.sku)}</td><td>${esc(o.asin)}</td><td>${esc(o.country)}</td><td>${esc(o.brand)}</td><td>${esc(o.group)}</td><td class="num">${fmt(o.sales)}</td><td class="num">${fmt(o.returns)}</td><td class="num">${pct(o.rate)}</td><td class="health ${esc(o.risk)}">${esc(o.risk)}</td><td>${esc(o.owner)}</td><td>${esc(o.topReason)}</td><td>${esc(o.qe)}</td><td>${esc(o.sla)}</td></tr>`); table('tblSku',['SKU','ASIN','国家','品牌','品类组','销量','退货量','退货率','健康度','负责人','TOP原因','QE状态','SLA'],rows); }
function renderReason(){ const m=new Map(); for(const r of state.filtered){ const k=r.reasonGroup||'其他原因'; const o=m.get(k)||{name:k,returns:0,raw:new Map()}; o.returns+=r.returnQty; o.raw.set(r.reason,(o.raw.get(r.reason)||0)+r.returnQty); m.set(k,o); } const arr=[...m.values()].sort((a,b)=>b.returns-a.returns); renderBars('reasonBars',arr); renderPie('reasonPie','reasonLegend',arr); const total=arr.reduce((a,b)=>a+b.returns,0)||1; const rows=arr.slice(0,20).map((o,i)=>{ const raw=[...o.raw.entries()].sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]).join(' / '); return `<tr><td>${i+1}</td><td>${esc(o.name)}</td><td class="num">${fmt(o.returns)}</td><td class="num">${pct(o.returns/total)}</td><td class="noteCell">${esc(raw)}</td></tr>`; }); table('tblReason',['排名','中文原因组','退货量','占比','主要原始原因'],rows); }
function updateTrendValueOptions(){ const dim=$('trendDim').value; let arr=[]; if(dim==='country')arr=state.rows.map(x=>x.country); else if(dim==='brand')arr=state.rows.map(x=>x.brand); else if(dim==='group')arr=state.rows.map(x=>x.group); else if(dim==='sku')arr=state.rows.map(x=>x.sku); const el=$('trendValue'); const cur=el.value; el.innerHTML='<option value="">全部/Top</option>'+[...new Set(arr.filter(Boolean))].sort().map(x=>`<option>${esc(x)}</option>`).join(''); if([...el.options].some(o=>o.value===cur))el.value=cur; }
function renderTrend(){ const gran=$('trendGran').value, dim=$('trendDim').value, val=$('trendValue').value; const keyMap={year:'year',month:'month',week:'week',day:'day'}; let rows=state.filtered; if(dim!=='all' && val){ const prop={country:'country',brand:'brand',group:'group',sku:'sku'}[dim]; rows=rows.filter(r=>r[prop]===val); } const m=new Map(); for(const r of rows){ const k=r[keyMap[gran]]||''; if(k)m.set(k,(m.get(k)||0)+r.returnQty); } const data=[...m.entries()].sort().map(([x,y])=>({x,y})); drawLine(data); }
function drawLine(data){ const svg=$('trendLine'); const w=svg.clientWidth||900, h=245, pad=36; if(!data.length){ svg.innerHTML='<text x="30" y="40" fill="#667085">暂无趋势数据</text>'; return; } const max=Math.max(1,...data.map(d=>d.y)); const step=(w-pad*2)/Math.max(1,data.length-1); const pts=data.map((d,i)=>[pad+i*step,h-pad-(d.y/max)*(h-pad*2)]); const path=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' '); const labels=data.filter((_,i)=> i===0 || i===data.length-1 || i%Math.ceil(data.length/8)===0); svg.innerHTML=`<line x1="${pad}" y1="${h-pad}" x2="${w-pad}" y2="${h-pad}" stroke="#e5e7eb"/><line x1="${pad}" y1="${pad}" x2="${pad}" y2="${h-pad}" stroke="#e5e7eb"/><path d="${path}" fill="none" stroke="#2563eb" stroke-width="3"/>`+pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="3" fill="#2563eb"/>`).join('')+labels.map((d)=>{ const i=data.indexOf(d); const p=pts[i]; return `<text x="${p[0]}" y="${h-10}" font-size="10" text-anchor="middle" fill="#64748b">${esc(d.x)}</text>`; }).join('')+`<text x="${pad+5}" y="${pad-10}" font-size="11" fill="#64748b">Max ${fmt(max)}</text>`; }
function renderQE(){ const todo=state.skuAgg.filter(o=>!['已处理','不需处理'].includes(o.qe) && ['高风险','关注'].includes(o.risk)); const done=state.skuAgg.filter(o=>['已处理','不需处理'].includes(o.qe)); const row=o=>`<tr><td><input type="checkbox" class="sel" data-key="${esc(o.key)}" ${state.selected.has(o.key)?'checked':''}></td><td>${esc(o.sku)}</td><td>${esc(o.asin)}</td><td>${esc(o.country)}</td><td>${esc(o.group)}</td><td class="num">${fmt(o.sales)}</td><td class="num">${fmt(o.returns)}</td><td class="num">${pct(o.rate)}</td><td class="health ${esc(o.risk)}">${esc(o.risk)}</td><td>${esc(o.owner)}</td><td>${esc(o.topReason)}</td><td>${esc(o.qe)}</td><td>${esc(o.sla)}</td><td><input class="noteInput" data-key="${esc(o.key)}" value="${esc(o.note)}" placeholder="备注"></td></tr>`; table('tblQE',['选择','SKU','ASIN','国家','品类','销量','退货','退货率','健康','负责人','原因','QE状态','SLA','备注'],todo.map(row)); table('tblQEDone',['选择','SKU','ASIN','国家','品类','销量','退货','退货率','健康','负责人','原因','QE状态','SLA','备注'],done.map(row)); document.querySelectorAll('.sel').forEach(c=>c.onchange=()=>{ c.checked?state.selected.add(c.dataset.key):state.selected.delete(c.dataset.key); $('selInfo').textContent='已选择'+state.selected.size+'项'; }); document.querySelectorAll('.noteInput').forEach(inp=>inp.onchange=()=>{ const k=inp.dataset.key; qeState[k]=qeState[k]||{status:'待处理'}; qeState[k].note=inp.value; saveQE(); }); $('selInfo').textContent='已选择'+state.selected.size+'项'; }
function renderDetail(){ const ps=Number($('pageSize').value||100); state.pageSize=ps; const total=state.filtered.length; const pages=Math.max(1,Math.ceil(total/ps)); if(state.page>pages)state.page=pages; const rows=state.filtered.slice((state.page-1)*ps,state.page*ps).map(r=>`<tr><td>${r.id}</td><td>${esc(r.date)}</td><td>${esc(r.country)}</td><td>${esc(r.brand)}</td><td>${esc(r.sku)}</td><td>${esc(r.asin)}</td><td>${esc(r.group)}</td><td class="num">${fmt(r.returnQty)}</td><td>${esc(r.reasonGroup)}</td><td class="noteCell">${esc(r.reason)}</td><td class="noteCell">${esc(r.remark)}</td><td>${esc(r.order)}</td></tr>`); table('tblDetail',['ID','日期','国家','品牌','SKU','ASIN','品类组','数量','中文原因组','原始原因','买家备注','订单号'],rows); $('pageInfo').textContent=`第 ${state.page}/${pages} 页，共 ${fmt(total)} 行`; }
function renderAll(){ renderKpis(); renderSummary(); renderSku(); renderReason(); renderTrend(); renderQE(); renderDetail(); }
function resetFilters(){ document.querySelectorAll('#filters select,#filters input').forEach(el=>el.value=''); applyFilters(); }
function download(name, text, type='text/plain;charset=utf-8'){ const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([text],{type})); a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),2000); }
function exportCSV(){ const heads=['date','country','brand','sku','asin','group','returnQty','reasonGroup','reason','remark','order']; const lines=[heads.join(',')].concat(state.filtered.map(r=>heads.map(h=>'"'+String(r[h]??'').replace(/"/g,'""')+'"').join(','))); download('returns_filtered.csv',lines.join('\n'),'text/csv;charset=utf-8'); }
async function processFiles(){ try{ setStatus('正在解析文件，请稍候...'); if(!state.salesFile && !state.returnsFile) throw new Error('请至少上传销售数据和退货数据'); if(state.salesFile){ state.sales=parseSales(await fileToRows(state.salesFile)); } if(state.returnsFile){ let f=state.returnsFile; if(/\.zip$/i.test(f.name)) f=await extractFirstSheetFileFromZip(f); state.returns=parseReturns(await fileToRows(f)); } recomputeRows(); refreshFilters(); applyFilters(); setStatus(`更新完成：销售记录 ${fmt(state.sales.length)} 行，退货明细 ${fmt(state.returns.length)} 行。`, 'ok'); }catch(e){ console.error(e); setStatus('上传失败：'+e.message, 'bad'); } }
function exportJson(){ const payload={version:'6.0',createdAt:new Date().toISOString(),sales:state.sales,returns:state.returns}; download('dashboard-data.json',JSON.stringify(payload),'application/json;charset=utf-8'); }
async function importJson(file){ const data=JSON.parse(await file.text()); state.sales=data.sales||[]; state.returns=data.returns||[]; recomputeRows(); refreshFilters(); applyFilters(); setStatus(`JSON导入完成：销售 ${fmt(state.sales.length)} 行，退货 ${fmt(state.returns.length)} 行。`,'ok'); }
function bind(){
  $('salesFile').onchange=e=>{ state.salesFile=e.target.files[0]; setStatus('已选择销售文件：'+state.salesFile.name); };
  $('returnsFile').onchange=e=>{ state.returnsFile=e.target.files[0]; setStatus('已选择退货文件：'+state.returnsFile.name); };
  $('jsonFile').onchange=e=>{ if(e.target.files[0]) importJson(e.target.files[0]).catch(err=>setStatus('JSON导入失败：'+err.message,'bad')); };
  $('btnProcess').onclick=processFiles; $('btnExportJson').onclick=exportJson; $('btnClearData').onclick=()=>{ state.sales=[]; state.returns=[]; state.rows=[]; state.filtered=[]; refreshFilters(); applyFilters(); setStatus('已清空当前上传数据。'); };
  $('btnApply').onclick=applyFilters; $('btnReset').onclick=resetFilters; $('btnExport').onclick=exportCSV; $('pageSize').onchange=()=>{state.page=1;renderDetail();}; $('prevPage').onclick=()=>{if(state.page>1){state.page--;renderDetail();}}; $('nextPage').onclick=()=>{state.page++;renderDetail();};
  ['trendGran','trendDim','trendValue'].forEach(id=>$(id).onchange=()=>{ if(id==='trendDim') updateTrendValueOptions(); renderTrend(); });
  $('btnBulkApply').onclick=()=>{ const st=$('bulkStatus').value, note=$('bulkNote').value; for(const k of state.selected){ qeState[k]=qeState[k]||{}; qeState[k].status=st; if(note) qeState[k].note=note; } saveQE(); state.selected.clear(); applyFilters(); };
  $('btnSelectAll').onclick=()=>{ document.querySelectorAll('#tblQE .sel').forEach(c=>{ c.checked=true; state.selected.add(c.dataset.key); }); $('selInfo').textContent='已选择'+state.selected.size+'项'; };
  $('btnClearSel').onclick=()=>{ state.selected.clear(); document.querySelectorAll('.sel').forEach(c=>c.checked=false); $('selInfo').textContent='已选择0项'; };
  document.querySelectorAll('#topNav button').forEach(b=>b.onclick=()=>{ document.querySelectorAll('#topNav button').forEach(x=>x.classList.remove('active')); b.classList.add('active'); $(b.dataset.target).scrollIntoView({behavior:'smooth',block:'start'}); });
}
bind(); refreshFilters(); applyFilters();
