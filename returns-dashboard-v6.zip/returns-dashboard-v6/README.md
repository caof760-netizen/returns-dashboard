# 退货经营管理看板 V6.0 企业版

这是将原先 40MB+ 单文件 HTML 重构后的 GitHub Pages 项目结构。

## 文件结构

```text
returns-dashboard-v6/
├── index.html
├── css/dashboard.css
├── js/dashboard.js
├── libs/jszip.min.js
├── assets/
├── data/
├── .nojekyll
└── README.md
```

## 使用方法

1. 打开网页。
2. 上传“销量分析 Excel”。
3. 上传“退货(FBA)订单导出 ZIP 或 Excel”。
4. 点击“解析并更新看板”。
5. 看板的 KPI、筛选、搜索、趋势折线、TOP原因、SKU健康度、QE闭环、明细会自动刷新。

## 关于保存

静态 GitHub Pages 不能把用户上传的数据直接写回服务器。V6.0 提供：

- 导出当前数据 JSON：用于保留当前上传和解析后的数据快照。
- 导入已保存 JSON：下次打开网页后可快速恢复。
- QE 状态和备注：仅保存少量状态到浏览器 LocalStorage，不保存大数据，避免 quota 超限。

如果需要“一个人上传后，全公司打开同一网址都是最新数据”，建议下一步升级为带后端数据库的版本：

```text
前端 Dashboard + Node/Python API + SQLite/MySQL
```

## GitHub Pages 部署

1. 将本项目所有文件上传到 Repository 根目录。
2. 打开 Settings → Pages。
3. Source 选择 Deploy from a branch。
4. Branch 选择 main，Folder 选择 /(root)。
5. 保存后等待 1 分钟，即可获得公开网址。

## 注意

Excel 解析依赖 SheetJS CDN：

```html
https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js
```

如果公司网络不能访问 CDN，可将 `xlsx.full.min.js` 下载到 `libs/`，并把 `index.html` 中对应脚本地址改为本地路径。
